# BI-GDP & BiosphereChain

**Author:** Gaudhi De Sedas (@hunnets)  
**License:** MIT

This repository hosts the open-source framework for the BiosphereChain blockchain and the BI-GDP model aligning economics with biodiversity and ecosystem intelligence.

## Contents
- BI-GDP Framework
- BiosphereChain Blockchain Description
- Example Chain Data Format
- License (MIT)