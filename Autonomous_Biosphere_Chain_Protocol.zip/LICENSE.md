MIT License / Creative Commons Zero v1.0 Universal (CC0 1.0)

Permission is hereby granted to use this work for any purpose without restriction. No rights reserved.
