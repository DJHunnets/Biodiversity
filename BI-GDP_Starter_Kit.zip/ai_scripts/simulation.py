
# Simple BI-GDP AI simulation script
print("Welcome to the BI-GDP AI prototype.")
print("This system is designed to receive inputs and respond with biosphere-aligned logic.")

while True:
    question = input("Ask something about policy, ecology, economics, or technology: ")
    if 'exit' in question.lower():
        print("Exiting the simulation. Stay aligned.")
        break
    print(f"Your input was received. Imagine an AI aligned with biosphere intelligence would now respond with regenerative guidance.
")
