
# BI-GDP Starter Kit

This package is a beginner-friendly starting point for creating a biosphere-aligned autonomous AI.

## What's Included

- `ethics_core/ethics.json`: Your foundational ethics file
- `ai_scripts/simulation.py`: A simple interactive script
- `biosphere_journal/`: Where AI insights or thoughts can be saved
- `readme/README.txt`: This file

## How to Start

1. Open a terminal or command line
2. Navigate to this folder
3. Run the AI simulation script:

```
python3 ai_scripts/simulation.py
```

Ask it questions about sustainability, development, or ethics — and reflect on what an aligned AI might say.

This is your first step in growing BI-GDP. 🌱
